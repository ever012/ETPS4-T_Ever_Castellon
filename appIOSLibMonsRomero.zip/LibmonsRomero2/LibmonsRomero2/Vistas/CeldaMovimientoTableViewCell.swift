//
//  CeldaMovimientoTableViewCell.swift
//  LibmonsRomero2
//
//  Created by Development on 30/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class CeldaMovimientoTableViewCell: UITableViewCell {

    
    @IBOutlet weak var lblTipoMov: UILabel!
    @IBOutlet weak var lblVenta: UILabel!
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
