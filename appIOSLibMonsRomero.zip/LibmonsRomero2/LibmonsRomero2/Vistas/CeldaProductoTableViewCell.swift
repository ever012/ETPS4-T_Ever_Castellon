//
//  CeldaProductoTableViewCell.swift
//  LibmonsRomero2
//
//  Created by Development on 28/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class CeldaProductoTableViewCell: UITableViewCell {

    @IBOutlet weak var lblNombreProd: UILabel!
    
    @IBOutlet weak var lblPrecioProd: UILabel!
    
    @IBOutlet weak var lblId: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
