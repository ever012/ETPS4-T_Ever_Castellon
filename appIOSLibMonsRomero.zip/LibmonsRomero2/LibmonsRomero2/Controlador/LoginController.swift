//
//  ViewController.swift
//  LibmonsRomero2
//
//  Created by Development on 28/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit
class LoginController: UIViewController {
    
    //MARK: Outlets - conexiones
    
    @IBOutlet weak var lblUsuario: UITextField!
    @IBOutlet weak var lblClave: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    @IBAction func btnIniciarSesion(_ sender: UIButton) {
        //El "guard" se utiliza para verificar si ambos valores existen, es decir, si no son nulos.
        guard let usuario = lblUsuario.text, let clave = lblClave.text else {
            return    //si son nulos retornará vacio y no avanzarà el codigo
        }
        
        // Construir el cuerpo de la solicitud
        let parametros: [String: Any] = [ //voy a enviar estos datos en la peticion http
            "usuario": usuario,
            "clave": clave
        ]
        //convierto el arreglo "parametros" en un JSON
        guard let jsonData = try? JSONSerialization.data(withJSONObject: parametros) else {
            return
        }
        
        // Crear la solicitud HTTP
        let urlString = linkAPI.baseUrlString + "usuario/login" //link de la api
        
        //la funcion URL() se usa para convertir un texto en un link valido para usar en swift
        guard let url = URL(string: urlString) else { //verifico que puedo ver la info
            return
        }
        var request = URLRequest(url: url)  //creo una instancia de una peticion http
        request.httpMethod = "POST" //metodo a usar en èsta peticion
        request.setValue("application/json", forHTTPHeaderField: "Content-Type") //para evitar algun problema le digo desde yá que enviaré un json
        request.httpBody = jsonData //envio los parametros con la peticion
        
        // Enviar la solicitud
        //"URLSession.shared" envia la solicitud http, pero le digo que aparte de enviar datos, con "dataTask" le digo que espero una respuesta
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                //data = respuesta de la api
                //response = respuesta de la peticion http
                //error = error durante en envio de la peticion http
                print("Error: \(error.localizedDescription)")
                return
            }
            if let data = data { //si hay una respuesta de la api entonces...
                // Parsear la respuesta JSON
                //convierto el JSON en un arreglo String, try? se usa en caso de error retornar nulo
                if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                     //asigno a result el valor del arreglo
                    //asigno a success el valor del arreglo
                    let result = json?["result"] as? String, let success = json?["success"] as? Bool {
                    //si el success de la respuesta de la API es false entonces no dejarà iniciar session
                        if success == false{
                            print("result: \(result)" )
                            return  //se detiene y no inicia sesion
                        }
                    // Guardar la respuesta en una cookie
                    let cookieProperties: [HTTPCookiePropertyKey: Any] = [
                        .name: "respuestaAPI",
                        .value: result,
                        .domain: "ejemplo.com", //indica a qué dominio pertenece la cookie y en qué dominios será enviada de vuelta al servidor.(se dejò èse porque el dominio en nuestro caso no hay uno especifico).
                        .path: "/", //ruta en la que se guardará la cookie, en este caso se guarda en la raiz del proyecto es decir, la cookie será válida para todo el sitio o dominio.
                    // Otros atributos opcionales.
                    ]
                    //si se logrò crear la cookie entonces la guardo
                    if let cookie = HTTPCookie(properties: cookieProperties) {
                        HTTPCookieStorage.shared.setCookie(cookie)
                        //HTTPCookieStorage es ele almacenamiento compartido de cookies
                        
                    }
                    
                    // Mostrar la vista de productos
                    DispatchQueue.main.async {
                        
                        //creo una instancia de la vista y la muestro en pantalla
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaInicio")
                        self.present(vistaMostrada, animated: true)
                        
                    }
                    
                    
                } else {
                    // Error al parsear la respuesta JSON
                    print("Error al parsear la respuesta JSON")
                }
            }
            }.resume() //es de "URLSession.shared.dataTask" usado anteriormente.
        
            //la funcion resume() se utiliza para iniciar la tarea de datos(dataTask) y enviar la solicitud HTTP al servidor, se coloca al final para asegurarse de que la tarea de datos esté lista para ser ejecutada. Sin esta llamada, la tarea de datos no se iniciaría y la solicitud no se enviaría al servidor.
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
