//
//  MovimientoController.swift
//  LibmonsRomero2
//
//  Created by Development on 30/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class MovimientoController: UIViewController,UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource,UITextFieldDelegate{

    let data = ["COMPRA","VENTA"] // Datos para el menú desplegable 1
    //let data2 = ["Item 1", "Item 2", "Item 3"] //Datos ejemplo para el menu desplegable 2
    
    var selectedOption: String? // Opción seleccionada del menu 1
    var selectedOptionId: String? //guarda inicial de la opcion seleccionada del menu 1
    
    var selectedOption2: String? //guarda nombre producto menu 2 desplegable
    var selectedOptionIdProd: String? //guarda id producto menu 2
    var txtid_movi: Int?
    var txtGuardarPrecio: Decimal?
    
    private var datePicker: UIDatePicker? //para la fecha
    
    
    //estructura para las categorias
    struct MovimientosModelo: Codable {
        var result: [Movimiento] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct Movimiento: Codable{
        //las variables se deben llamar igual a como esta en la API
        let id_Movimiento: Int?
        let id_producto: Int?
        let tipoMovi: String?
        let cantidad: Int?
        let total: Decimal?
        let fecha: String?
        let nombre_producto: String?
        let precio: Decimal?
    }
    
    
    //estructura de la respuesta de la API
    struct APIResponse: Codable {
        let success: Bool
        let message: String
        let result: String
    }
    
    
    //arreglos donde se guardarà la informacion obtenida de la api
    var itemsMovimientos : [Movimiento] = []
    
    //OBJETOS DE LA VISTA PRODUCTOS
    @IBOutlet weak var txtProducto: UITextField! //menu desplegable 2
    @IBOutlet weak var txtIdProd: UITextField!
    @IBOutlet weak var txtPrecio: UITextField!
    @IBOutlet weak var txtCantidad: UITextField!
    @IBOutlet weak var txtTotal: UITextField!
    @IBOutlet weak var txtMovimiento: UITextField! //menu desplegable 1
    
    @IBOutlet weak var dateTextField: UITextField!
    

    @IBOutlet weak var tablaMovimientos: UITableView!
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tablaMovimientos.delegate = self
        tablaMovimientos.dataSource = self
        obtenerMovimientos()
        
        
        // Crear y configurar el UIPickerView 1
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        
        // Crear y configurar el UIPickerView 2
        let pickerView2 = UIPickerView()
        pickerView2.delegate = self
        pickerView2.dataSource = self
        
        
        // Asignar el UIPickerView al campo de texto o botón donde quieres mostrar el menú desplegable
        // Por ejemplo, si tienes un campo de texto llamado "textField":
        txtMovimiento.inputView = pickerView
        txtProducto.inputView = pickerView2

        // Configurar una barra de herramientas con un botón "Done" para cerrar el menú desplegable
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)
        txtMovimiento.inputAccessoryView = toolbar
        txtProducto.inputAccessoryView = toolbar
        
        
        //MARK: DATE PICKER
        // Configurar el text field como delegado
        dateTextField.delegate = self
        
        // Configurar el modo del date picker
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .dateAndTime
        
        // Configurar el formato del date picker
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy hh:mm a"
        dateTextField.text = dateFormatter.string(from: Date())
        
        // Asignar el date picker al inputView del text field
        dateTextField.inputView = datePicker
        
        // Agregar un botón de "Listo" en el teclado del text field
        let toolbar2 = UIToolbar(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 44))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton2 = UIBarButtonItem(title: "Listo", style: .done, target: self, action: #selector(doneButtonTapped2))
        toolbar2.setItems([flexibleSpace, doneButton2], animated: true)
        dateTextField.inputAccessoryView = toolbar2
        
        
        // Agregar el observador de notificación para el evento "editingDidEnd" del txtCantidad
        NotificationCenter.default.addObserver(self, selector: #selector(txtCantidadEditingDidEnd), name: NSNotification.Name.UITextFieldTextDidEndEditing, object: txtCantidad)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    //MARK: OPERCIONES DATE PICKER
    @objc func doneButtonTapped2() {
        // Obtener la fecha seleccionada del date picker
        let selectedDate = datePicker?.date
        
        // Configurar el formato del date picker
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy hh:mm a"
        
        // Convertir la fecha a un string
        let dateString = dateFormatter.string(from: selectedDate!)
        
        // Asignar el string al text field
        dateTextField.text = dateString
        
        // Ocultar el teclado
        dateTextField.resignFirstResponder()
    }
    
    // Implementar el delegado del text field para ocultar el teclado al tocar fuera del text field
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        dateTextField.resignFirstResponder()
    }
    
    
    // MARK: Operaciones CRUD
    func obtenerMovimientos(){
        let urlString = linkAPI.baseUrlString + "movimiento/verMovimientos"
        
        if let url = URL(string: urlString){
            if let data = try? Data(contentsOf: url){
                
                let decodificador = JSONDecoder()
                if let datosDecodificados = try? decodificador.decode(MovimientosModelo.self, from: data) {
                    
                    //print("datosDecodificados: \(datosDecodificados.result)")// prueba
                    itemsMovimientos = datosDecodificados.result
                    
                }
            }
        }
    }
    
    // MARK: - UIPickerViewDelegate y UIPickerViewDataSource
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Número de componentes en el menú desplegable (en este caso, solo 1)
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == txtMovimiento.inputView as? UIPickerView {
            return data.count
        } else if pickerView == txtProducto.inputView as? UIPickerView {
            return itemsMovimientos.count
        }
        
        return 0
    
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == txtMovimiento.inputView as? UIPickerView {
            return data[row]
        } else if pickerView == txtProducto.inputView as? UIPickerView {
            return itemsMovimientos[row].nombre_producto // Texto que se muestra para cada fila del menú desplegable
            
        }
        
        return nil

    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == txtMovimiento.inputView as? UIPickerView {
            selectedOption = data[row] // Almacenar la opción seleccionada
            
            if selectedOption == "COMPRA" {
                selectedOptionId = "C"
            }
            if selectedOption == "VENTA" {
                selectedOptionId = "V"
            }
            
            //aqui hay un problema y es que no se muestra ningun dato en menu desplegable de producto ***
        } else if pickerView == txtProducto.inputView as? UIPickerView {
            selectedOption2 = itemsMovimientos[row].nombre_producto // Almacenar nombre producto
            
            if let idproducto = itemsMovimientos[row].id_producto { //almacenar id producto
                selectedOptionIdProd = String(idproducto)
            } else {
                selectedOptionIdProd = nil
            }
            
            txtGuardarPrecio = itemsMovimientos[row].precio //almacenar precio
        }
    }
    
    // MARK: - Acciones
    
    @objc func doneButtonTapped() { //Realizar acciones con las opciones seleccionadas en los menús desplegables
        
        // Cerrar el menú desplegable y actualizar el campo de texto o botón con la opción seleccionada
        txtMovimiento.text = selectedOptionId
        txtMovimiento.resignFirstResponder() // Cerrar el teclado
        
        txtProducto.text = selectedOption2
        txtIdProd.text = selectedOptionIdProd
        if let guardarPrecio = txtGuardarPrecio {
            txtPrecio.text = String(describing: guardarPrecio)
        } else {
            txtPrecio.text = ""
        }
        
        txtProducto.resignFirstResponder()
    }
    
    
    // MARK: - DataSource y DataDelegate de la table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsMovimientos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let celda = tablaMovimientos.dequeueReusableCell(withIdentifier: "celdaMovimiento", for: indexPath) as! CeldaMovimientoTableViewCell
        let celda:CeldaMovimientoTableViewCell = tableView.dequeueReusableCell(withIdentifier: "celda") as! CeldaMovimientoTableViewCell
        
        celda.lblTipoMov.text = itemsMovimientos[indexPath.row].tipoMovi //tipo movimiento
        
        if let totalVenta = itemsMovimientos[indexPath.row].total { //total venta
            celda.lblVenta.text = String(describing: totalVenta)
        } else {
            celda.lblVenta.text = "N/A"
        }

        
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        txtProducto.text = itemsMovimientos[indexPath.row].nombre_producto
        
        if let id_prod = itemsMovimientos[indexPath.row].id_producto {
            txtIdProd.text = String(id_prod)
        } else {
            txtIdProd.text = nil
        }
        if let precio = itemsMovimientos[indexPath.row].precio {
            txtPrecio.text = String(describing: precio)
        } else {
            txtPrecio.text = nil
        }
        if let cantidad = itemsMovimientos[indexPath.row].cantidad {
            txtCantidad.text = String(cantidad)
        } else {
            txtCantidad.text = nil
        }
        if let total = itemsMovimientos[indexPath.row].total {
            txtTotal.text = String(describing: total)
        } else {
            txtTotal.text = nil
        }
        
        txtMovimiento.text = itemsMovimientos[indexPath.row].tipoMovi
        
        // Configurar el formato de la fecha que viene de la api
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        // Obtener la fecha del arreglo
            if let fechaString = itemsMovimientos[indexPath.row].fecha {
                //aqui imprime 2023-04-29T00:00:00
            if let fecha = dateFormatter.date(from: fechaString) {
                //aqui fecha = 2023-04-29 07:00:00 +0000
                
                //lo vuelvo a formatear para que coincida con el formato del data picker
                let displayDateFormatter = DateFormatter()
                displayDateFormatter.dateFormat = "dd/MM/yyyy hh:mm a"
                dateTextField.text = displayDateFormatter.string(from: fecha)
                datePicker?.date = fecha
            }
        
        }
        
        txtid_movi = itemsMovimientos[indexPath.row].id_Movimiento
        //dateTextField.text = itemsMovimientos[indexPath.row].fecha
        
    }
    
    
    //PARA QUE AL PERDER EL FOCO EN txtCantidad automaticamente haga el total
    @objc func txtCantidadEditingDidEnd() {
        if let cantidadString = txtCantidad.text, let cantidad = Int(cantidadString), let precioString = txtPrecio.text, let precio = Decimal(string: precioString) {
            let cantidadDecimal = Decimal(cantidad)
            let total = cantidadDecimal * precio
            txtTotal.text = "\(total)"
        } else {
            txtTotal.text = ""
        }
    }
    
    deinit {
        // Eliminar el observador de notificación al salir de la vista
        NotificationCenter.default.removeObserver(self)
    }
    
    
    
    //MARK: CRUD
    func agregarMovimiento() {
        let urlString = linkAPI.baseUrlString + "movimiento/insertarMovimiento"
        
        guard let id_producto = Int(txtIdProd.text ?? ""),
            let TipoMovi = txtMovimiento.text,
            let cantidadMov = Int(txtCantidad.text ?? ""),
            let totalMov = Decimal(string: txtTotal.text ?? ""),
            let fechaMov = dateTextField.text else {
                return
        }
        
        let nuevoMovimiento = Movimiento(id_Movimiento: nil,
                                         id_producto: id_producto,
                                         tipoMovi: TipoMovi,
                                       cantidad: cantidadMov,
                                       total: totalMov,
                                       fecha: fechaMov,
                                       nombre_producto: nil,
                                       precio: nil
                                       )
        
        guard let jsonData = try? JSONEncoder().encode(nuevoMovimiento) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                let decodificador = JSONDecoder()
                
                if let movimientoAgregado = try? decodificador.decode(Movimiento.self, from: data) {
                    // Producto agregado con éxito
                    self.itemsMovimientos.append(movimientoAgregado)
                    print("movimiento agregado")
                    DispatchQueue.main.async {
                        self.tablaMovimientos.reloadData()
                    }
                } else {
                    // Error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume()
    }
    
    

    
    func eliminarMovimiento() {
        let urlString = linkAPI.baseUrlString + "movimiento/eliminarMovimiento"
        
        guard let id_Mov = txtid_movi else {
            return
        }

        let MovimientoAEliminar = Movimiento(id_Movimiento: id_Mov,
                                           id_producto: nil,
                                           tipoMovi: nil,
                                           cantidad: nil,
                                           total: nil,
                                           fecha: nil,
                                           nombre_producto: nil,
                                           precio: nil
        )
        
        guard let jsonData = try? JSONEncoder().encode(MovimientoAEliminar) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "DELETE"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Agregar el valor de la cookie al encabezado de la solicitud
        if let cookieValue = obtenerCookieValue() {
            request.setValue(cookieValue, forHTTPHeaderField: "Authorization")
        }
        
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                let decodificador = JSONDecoder()
                if let respuesta = try? decodificador.decode(APIResponse.self, from: data) {
                    print("Message: \(respuesta.message) ") //si no se elimino, muestra mensaje
                    
                    if respuesta.success == true{ //en caso de que si se haya eliminado
                        print("movimiento eliminado ✔" )
                    }
                    
                } else {
                    print("Error al decodificar la respuesta del servidor")
                    
                    
                }
            }
            }.resume()
    }
    
    func obtenerCookieValue() -> String? {
        // Obtener la cookie creada previamente en otro controlador
        // y devolverla para su uso en la solicitud HTTP actual
        // Puedes ajustar este código según cómo hayas almacenado y accedido a la cookie
        let cookieName = "respuestaAPI"
        if let cookie = HTTPCookieStorage.shared.cookies?.first(where: { $0.name == cookieName }) {
            //print("RespuestaCookie:Bearer \( cookie.value)   ***FIN")
            return "Bearer " + cookie.value
            
        }
        return nil
    }
    
    
    
    
    
    
    @IBAction func btnCerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func btnAgregar(_ sender: UIButton) {
        agregarMovimiento()
    }
    @IBAction func btnEliminar(_ sender: UIButton) {
        eliminarMovimiento()
    }
    @IBAction func btnActualizarListaMov(_ sender: UIButton) {
        obtenerMovimientos()
        tablaMovimientos.reloadData()
    }
    
    
    
    
    
    
    
    
    
    
    
    

}










































