//
//  ProductoController.swift
//  LibmonsRomero2
//
//  Created by Development on 28/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class ProductoController: UIViewController,UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource{

    var selectedOption: String? // Opción seleccionada por el usuario
    var selectedOptionId: String? //variable donde se guarda el id del producto que el usuario seleccionò
    
    //estructura para la los productos
    struct ProductosModelo: Codable {
        var result: [Producto] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct Producto: Codable{
        //las variables se deben llamar igual a como esta en la API
        let id_producto: Int?
        let nombre_producto: String?
        let id_categoria: Int?
        let precio: Decimal?
        let descripcion: String?
        let cantidad: Int?
        let estado: String?
        let precio_venta: Decimal?
    }
    
    //estructura para las categorias
    struct CategoriasModelo: Codable {
        var result: [Categoria] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct Categoria: Codable{
        //las variables se deben llamar igual a como esta en la API
        let id_categoria: Int?
        let nombCate: String?
        let descripcionCate: String?
        let ESTADO: String?
    }
    
    
    //estructura de la respuesta de la API
    struct APIResponse: Codable {
        let success: Bool
        let message: String
        let result: String
    }
    
    
    //arreglos donde se guardarà la informacion obtenida de la api
    var articuloProductos : [Producto] = []
    var itemsCategorias : [Categoria] = []
    
    //OBJETOS DE LA VISTA PRODUCTOS
    @IBOutlet weak var tablaProducto: UITableView!
    @IBOutlet weak var txtCodigo: UITextField!
    @IBOutlet weak var txtNombrePRoducto: UITextField!
    @IBOutlet weak var txtCategoria: UITextField!
    @IBOutlet weak var txtPrecio: UITextField!
    @IBOutlet weak var txtDescripcion: UITextField!
    @IBOutlet weak var txtCantidad: UITextField!
    @IBOutlet weak var txtEstado: UITextField!
    @IBOutlet weak var txtPrecioVenta: UITextField!
    @IBOutlet weak var viewAgregarCategoria: UIView!
    
    
    @IBOutlet weak var txtCodigoCate: UITextField!
    @IBOutlet weak var txtNombreCate: UITextField!
    @IBOutlet weak var txtDescripcionCate: UITextField!
    @IBOutlet weak var txtEstadoCate: UITextField!
    

    @IBOutlet weak var lblResspuestaCate: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        //registrar la celda personalizada, en la tabla y ponerle un nombre
        tablaProducto.register(UINib(nibName: "CeldaProductoTableViewCell", bundle: nil), forCellReuseIdentifier: "celdaProducto")
        
        //le digo que la clase actual será el delegado y el origen de datos de la tabla
        tablaProducto.delegate = self //el delegado maneja los eventos de interaccion con el usuario
        tablaProducto.dataSource = self
        listarProductos() //llama a la funcion para que obtenga los productos de la api
        obtenerCategorias() //llamo a la funcion para que obtenga los productos de la api
        
        
        // Crear y configurar el UIPickerView
        let pickerView = UIPickerView() //creo una instancia de pickerView
        //le digo que la clase actual será el delegado y el origen de datos del pickerView
        pickerView.delegate = self
        pickerView.dataSource = self
        
        // Asignar el UIPickerView al campo de texto o botón donde quiero mostrar el menú desplegable
        txtCategoria.inputView = pickerView //el input harà de pickerView
        
        // Configurar una barra de herramientas con un botón "Done" para cerrar el menú desplegable
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)
        txtCategoria.inputAccessoryView = toolbar
        
        viewAgregarCategoria.isHidden = true //ocultar view de categorias
        
    }

    
    //En caso de alguna falta de memoria o problema con la app
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

    }
    
    
    
    func listarProductos(){
        let urlString = linkAPI.baseUrlString + "productos/verProductos" //link de la api
        
        //la funcion URL() se usa para convertir un texto en un link valido para usar en swift
        if let url = URL(string: urlString){ //si se puede ver la info, entonces...
            //intento obtener los datos de la URL y los asigno a "data", try? se usa en caso de error retornar nulo
            if let data = try? Data(contentsOf: url){ //si no hay error, entonces...
                
                let decodificador = JSONDecoder() //creo una instancia del decodificador
                //intento decodificar los datos que estan en formato JSON y convertirlos en un arreglo con la estructura de "ProductosModelo"
                if let datosDecodificados = try? decodificador.decode(ProductosModelo.self, from: data) { //si la decodificacion es exitosa, entonces...
                    
                    //print("datosDecodificados: \(datosDecodificados.result.count)")// prueba
                    articuloProductos = datosDecodificados.result //guardo los resultados en el arreglo
                    tablaProducto.reloadData() //hace que la tabla se recargue o actualice
                }
            }
        }
    }
    
    func obtenerCategorias(){
        let urlString = linkAPI.baseUrlString + "categoria/verCategorias" //link de la api
    
        if let url = URL(string: urlString){ //reviso si se puede acceder a la info
            if let data = try? Data(contentsOf: url){ //esa info la guardo en una variable
    
                let decodificador = JSONDecoder() //creo una instancia del decodificador
                
                //convierto los datos JSON a un arreglo con estructura igual a la de "CategoriasModelo"
                if let datosDecodificados = try? decodificador.decode(CategoriasModelo.self, from: data) {
    
                    //print("datosDecodificados: \(datosDecodificados.result.count)")// prueba
                    itemsCategorias = datosDecodificados.result
                    
                }
            }
        }
    }
    // MARK: - UIPickerViewDelegate y UIPickerViewDataSource
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Número de componentes en el menú desplegable (en este caso, solo 1 porque solo se mostrarà el "nombre de la categoria")
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return itemsCategorias.count // Número de elementos en el menú desplegable
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        //mostrar un listado con todos los nombres
        return itemsCategorias[row].nombCate // Texto que se muestra para cada fila del menú desplegable
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedOption = itemsCategorias[row].nombCate // Almacenar la opción seleccionada
        
        //Almacenar id de opcion sleccionada
        //como el id es de tipo entero entonces debo convertirlo a string
        //asigno el valor de la variable en base de si existe o no
        if let idCategoria = itemsCategorias[row].id_categoria {
            selectedOptionId = String(idCategoria)
        } else {
            selectedOptionId = nil
        }
        
    }
    
    // MARK: - Acciones
    
    @objc func doneButtonTapped() { //funcion para saber la opcion que presionò el usuario
        
        // Cerrar el menú desplegable y actualizar el campo de texto o botón con la opción seleccionada
        txtCategoria.text = selectedOptionId //le digo que en cuadro de texto aparezca el id y no el nombre de la categoria
        txtCategoria.resignFirstResponder() // Cerrar el teclado
    }
    
    
    
    
    // MARK: - Manejadores de eventos
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articuloProductos.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //asigno el table view cell que cree "CeldaProductoTableViewCell" a la celda en la tabla, a modo de sustituir el que tiene por defecto, por el de "CeldaProductoTableViewCell"
        let celda = tablaProducto.dequeueReusableCell(withIdentifier: "celdaProducto", for: indexPath) as! CeldaProductoTableViewCell
        
        //establezco los valores de la celda
        if let id = articuloProductos[indexPath.row].id_producto {
            celda.lblId.text = String(id)
        } else {
            celda.lblId.text = nil
        }
        
        celda.lblNombreProd.text = articuloProductos[indexPath.row].nombre_producto
        
        if let precio = articuloProductos[indexPath.row].precio {
            celda.lblPrecioProd.text = String(describing: precio)
        } else {
            celda.lblPrecioProd.text = "N/A" // Valor predeterminado si precio es nulo
        } //con String(describing:), Swift intentará convertir automáticamente el valor de tipo Decimal a su representación en forma de cadena
        
        return celda
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //asigno los valores de la tabla con sus respectivos cuadros de texto
        
        if let id_prod = articuloProductos[indexPath.row].id_producto { //id_producto
            txtCodigo.text = String(id_prod)
        } else {
            txtCodigo.text = nil
        }
        //imprimo nombre_producto
        txtNombrePRoducto.text = articuloProductos[indexPath.row].nombre_producto

        if let id_cat = articuloProductos[indexPath.row].id_categoria { //id_categoria
            txtCategoria.text = String(id_cat)
        } else {
            txtCategoria.text = nil
        }

        if let precio = articuloProductos[indexPath.row].precio { //precio
            txtPrecio.text = String(describing: precio)
        } else {
            txtPrecio.text = "N/A" // Valor predeterminado si precio es nulo
        }
        
        //imprimo descripcion
        txtDescripcion.text = articuloProductos[indexPath.row].descripcion

        if let cantidad = articuloProductos[indexPath.row].cantidad { //cantidad
            txtCantidad.text = String(cantidad)
        } else {
            txtCantidad.text = nil
        }
        //imprimo estado
        txtEstado.text = articuloProductos[indexPath.row].estado

        if let precioVenta = articuloProductos[indexPath.row].precio_venta { //precio venta
            txtPrecioVenta.text = String(describing: precioVenta)
        } else {
            txtPrecioVenta.text = "N/A" // Valor predeterminado si es nulo
        }

    }
    
    
  


    // MARK: Operaciones CRUD
    func agregarProducto() {
        let urlString = linkAPI.baseUrlString + "productos/agregarProducto" //link
        
        //establezco los datos a enviar y verifico con "guard" que no esten vacios
        guard let nombreProducto = txtNombrePRoducto.text,
            let idCategoria = Int(txtCategoria.text ?? ""), //en caso de nulo sera vacio
            let precio = Decimal(string: txtPrecio.text ?? ""),
            let descripcion = txtDescripcion.text,
            let cantidad = Int(txtCantidad.text ?? ""),
            let estado = txtEstado.text,
            let precioVenta = Decimal(string: txtPrecioVenta.text ?? "") else {
                return
        }
        
        //establezco la estructura de la api y dejo como nulos los datos que no seràn enviados
        let nuevoProducto = Producto(id_producto: nil,
                                     nombre_producto: nombreProducto,
                                     id_categoria: idCategoria,
                                     precio: precio,
                                     descripcion: descripcion,
                                     cantidad: cantidad,
                                     estado: estado,
                                     precio_venta: precioVenta)
        
        //convierto a JSON la variable donde estan los parametros
        guard let jsonData = try? JSONEncoder().encode(nuevoProducto) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!) //creo instancia de peticion
        request.httpMethod = "POST" //metodo a usar
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData //agrego los datos
        
        //envio solicitud http y espero respuesta
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data { //si hay respuesta...
                let decodificador = JSONDecoder() //creo instancia
                
                //decodifico los datos
                if let productoAgregado = try? decodificador.decode(Producto.self, from: data) {
                    // Producto agregado con éxito
                    
                    print("se agrego producto")
                    self.articuloProductos.append(productoAgregado)//agrego los productos al arreglo
                    DispatchQueue.main.async {
                        self.tablaProducto.reloadData() //actualizo la tabla
                    }
                } else {
                    // Error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume() //es de "URLSession.shared.dataTask" usado anteriormente, es para proceder con el envio de la solicitud http.
        
    }
    
    
    
    func actualizarProducto() {
        let urlString = linkAPI.baseUrlString + "productos/actualizarProducto" //link
        
        //establezco los datos a enviar y verifico con "guard" que no esten vacios
        guard let codigo = Int(txtCodigo.text ?? ""),
            let nombreProducto = txtNombrePRoducto.text,
            let idCategoria = Int(txtCategoria.text ?? ""), //en caso de nulo, sera vacio
            let precio = Decimal(string: txtPrecio.text ?? ""),
            let descripcion = txtDescripcion.text,
            let cantidad = Int(txtCantidad.text ?? ""),
            let estado = txtEstado.text,
            let precioVenta = Decimal(string: txtPrecioVenta.text ?? "") else {
                return
        }
        
        //establezco la estructura de la api y dejo como nulos los datos que no seràn enviados
        let productoActualizado = Producto(id_producto: codigo,
                                           nombre_producto: nombreProducto,
                                           id_categoria: idCategoria,
                                           precio: precio,
                                           descripcion: descripcion,
                                           cantidad: cantidad,
                                           estado: estado,
                                           precio_venta: precioVenta)
        
        //convierto a JSON la variable donde estan los parametros
        guard let jsonData = try? JSONEncoder().encode(productoActualizado) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!) //creo instancia de peticion
        request.httpMethod = "PATCH" //metodo http a usar
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData //agrego los parametros a la peticion
        
        //hago la solicitud http
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error { //en caso de error
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data { //si hay respuesta de la api...
                let decodificador = JSONDecoder() //creo una instancia del decodificador
                
                //decodifico los datos JSON y convierto arreglo con estructura de "APIResponse"
                if let respuesta = try? decodificador.decode(APIResponse.self, from: data) {
                    print("Message: \(respuesta.message) producto actualizado") //imprimo la respuesta obtenida
                } else {
                    //en caso de error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume() //es de "URLSession.shared.dataTask" usado anteriormente, es para proceder con el envio de la solicitud http.
        
    }
    
    
    
    func eliminarProducto() {
        let urlString = linkAPI.baseUrlString + "productos/eliminarProducto" //link
        
        //verifico con "guard" que no este vacio el cuadro de texto
        guard let codigo = Int(txtCodigo.text ?? "") else {
            return
        }
        
        //establezco la estructura de la api y dejo como nulos los datos que no seràn enviados
        let productoAEliminar = Producto(id_producto: codigo,
                                         nombre_producto: nil,
                                         id_categoria: nil,
                                         precio: nil,
                                         descripcion: nil,
                                         cantidad: nil,
                                         estado: nil,
                                         precio_venta: nil)
        
        //convierto la variable a un JSON
        guard let jsonData = try? JSONEncoder().encode(productoAEliminar) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!) //hago instancia de peticion
        request.httpMethod = "DELETE" //metodo http a usar
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Agregar el valor de la cookie al encabezado de la solicitud
        if let cookieValue = obtenerCookieValue() { //si hay cookie, entonces la mando en el encanbezado con el nombre "Authorization"
            request.setValue(cookieValue, forHTTPHeaderField: "Authorization")
        }
        
        request.httpBody = jsonData //agrego los parametros a la peticion
        
        //hago la solicitud http
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error { //en caso de error
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data { //si hay respuesta de la api, entonces...
                let decodificador = JSONDecoder() //creo una instancia del decodificador
                
                //decodifico los datos JSON y convierto en arreglo con estructura de "APIResponse"
                if let respuesta = try? decodificador.decode(APIResponse.self, from: data) {
                    print("Message: \(respuesta.message) ")//si no se elimino, muestra mensaje
                    
                    if respuesta.success == true{ //en caso de que si se haya eliminado
                        print("producto eliminado ✔" )
                    }
                    
                } else {
                    //en caso de error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume() //es de "URLSession.shared.dataTask" usado anteriormente, es para proceder con el envio de la solicitud http.
        
    }
    
    //obtener la cookie creada previamente en "LoginController"
    func obtenerCookieValue() -> String? {
        let cookieName = "respuestaAPI"
        if let cookie = HTTPCookieStorage.shared.cookies?.first(where: { $0.name == cookieName }) {
            //print("RespuestaCookie:Bearer \( cookie.value)   ***FIN")
            //al inicio agrego el texto "Bearer" ya que es necesario para la api
            return "Bearer " + cookie.value
            
        }
        return nil
    }
    
    

    
    // MARK: Operaciones CREATE CATEGORIA
    func agregarCategoria() {
        let urlString = linkAPI.baseUrlString + "categoria/agregarCategoria" //link
        
        //verifico con "guard" que los datos a enviar no esten vacios
        guard let nombreCate = txtNombreCate.text,
            let descripcionCategoria = txtDescripcionCate.text,
            let estadoCate = txtEstadoCate.text else {
                return
        }
        
        //establezco la estructura de la api y dejo como nulos los datos que no seràn enviados
        let nuevoCategoria = Categoria(id_categoria: nil,
                                     nombCate: nombreCate,
                                     descripcionCate: descripcionCategoria,
                                     ESTADO: estadoCate)
        
        //convierto la variable a un JSON
        guard let jsonData = try? JSONEncoder().encode(nuevoCategoria) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)//hago instancia de peticion
        request.httpMethod = "POST" //metodo http a usar
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData //agrego los datos a la peticion
        
        //hago la solicitud http
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error { //en caso de error
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {//si hay respuesta de la api, entonces...
                let decodificador = JSONDecoder() //creo instancia del decodificador
                
                //decodifico los datos JSON y convierto en arreglo con estructura de "Categoria"
                if let categoriaAgregado = try? decodificador.decode(Categoria.self, from: data) {
                    // Producto agregado con éxito
                    //agrego las categorias al arreglo
                    self.itemsCategorias.append(categoriaAgregado)
                    DispatchQueue.main.async {
                        self.lblResspuestaCate.text = "Listo! ya se agrego" //imprimo respuesta
                        print("categoria agregada")
                    }
                } else {
                    // Error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume() //es de "URLSession.shared.dataTask" usado anteriormente, es para proceder con el envio de la solicitud http.
        
    }
    
    
    
    @IBAction func btnCerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil) //cerrar la instancia actual.
        
    }
    
    @IBAction func btnAgregar(_ sender: UIButton) {
        agregarProducto() //llamo a la funcion agregar producto
        
    }
    
    @IBAction func btnActualizar(_ sender: UIButton) {
        actualizarProducto() //llamo a la funcion actualizar producto
        
    }
    
    @IBAction func btnEliminar(_ sender: UIButton) {
        eliminarProducto() //llamo a la funcion eliminar producto
        
    }
    
    @IBAction func btnACtualizarLista(_ sender: UIButton) {
        self.listarProductos() //obtengo nuevamente la info para la tabla productos
        self.obtenerCategorias() //obtengo y actualizo los datos del picker view
        self.tablaProducto.reloadData() //actualizo la tabla
    }
    
    @IBAction func btnMostrarAgregarCategoria(_ sender: UIButton) {
        viewAgregarCategoria.isHidden = false //para mostrar la vista de "agregar categorias"
    }
    
    
    @IBAction func vtncerrarAgregarCategoria(_ sender: UIButton) {
        viewAgregarCategoria.isHidden = true //para cerrar la vista de "agregar categorias"
        
    }
    
    
    @IBAction func btnGuardarCate(_ sender: UIButton) {
        self.lblResspuestaCate.text = "Listo! ya se agrego" //asigno texto a label
        agregarCategoria() //llamo a la funcion agregar categoria
    }
    

}





















