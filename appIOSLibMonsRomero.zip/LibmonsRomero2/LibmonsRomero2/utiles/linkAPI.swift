//
//  linkAPI.swift
//  LibmonsRomero2
//
//  Created by Development on 28/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import Foundation
struct linkAPI {
    static let baseUrlString = "https://d91d-20-168-203-65.ngrok-free.app/"
    //static let baseUrlString = "http://20.168.203.65/"
    
}
