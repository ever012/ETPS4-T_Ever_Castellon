//
//  CategoriaController.swift
//  LibmonsRomero2
//
//  Created by Development on 29/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class CategoriaController: UIViewController,UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource{

    let data = ["ACTIVO","INACTIVO"] // Datos para el menú desplegable
    var selectedOption: String? // Opción seleccionada
    var selectedOptionId: String?
    
    //estructura para las categorias
    struct CategoriasModelo: Codable {
        var result: [Categoria] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct Categoria: Codable{
        //las variables se deben llamar igual a como esta en la API
        let id_categoria: Int?
        let nombCate: String?
        let descripcionCate: String?
        let estado: String?
    }
    
    
    //estructura de la respuesta de la API
    struct APIResponse: Codable {
        let success: Bool
        let message: String
        let result: String
    }
    
    
    //arreglos donde se guardarà la informacion obtenida de la api
    var itemsCategorias : [Categoria] = []
    
    //OBJETOS DE LA VISTA PRODUCTOS
    @IBOutlet weak var txtCodigo: UITextField!
    @IBOutlet weak var txtNombreCategoria: UITextField!
    @IBOutlet weak var txtDescripcion: UITextField!
    @IBOutlet weak var txtEstado: UITextField!
    
    @IBOutlet weak var tablaCategoria: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //registrar la celda personalizada
        tablaCategoria.register(UINib(nibName: "CeldaCategoriaTableViewCell", bundle: nil), forCellReuseIdentifier: "celdaCategoria")
        
        tablaCategoria.delegate = self
        tablaCategoria.dataSource = self
        obtenerCategorias()
        
        
        // Crear y configurar el UIPickerView
        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        
        // Asignar el UIPickerView al campo de texto o botón donde quieres mostrar el menú desplegable
        // Por ejemplo, si tienes un campo de texto llamado "textField":
        txtEstado.inputView = pickerView
        
        // Configurar una barra de herramientas con un botón "Done" para cerrar el menú desplegable
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)
        txtEstado.inputAccessoryView = toolbar
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   
    // MARK: Operaciones CRUD
    func obtenerCategorias(){
        let urlString = linkAPI.baseUrlString + "categoria/verCategorias"
        
        if let url = URL(string: urlString){
            if let data = try? Data(contentsOf: url){
                
                let decodificador = JSONDecoder()
                if let datosDecodificados = try? decodificador.decode(CategoriasModelo.self, from: data) {
                    
                    //print("datosDecodificados: \(datosDecodificados.result)")// prueba
                    itemsCategorias = datosDecodificados.result
                    
                }
            }
        }
    }
    
    // MARK: - UIPickerViewDelegate y UIPickerViewDataSource
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Número de componentes en el menú desplegable (en este caso, solo 1)
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return data.count // Número de elementos en el menú desplegable
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return data[row] // Texto que se muestra para cada fila del menú desplegable
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedOption = data[row] // Almacenar la opción seleccionada
        
        if selectedOption == "ACTIVO" {
            selectedOptionId = "A"
        }
        if selectedOption == "INACTIVO" {
            selectedOptionId = "I"
        }
        
    }
    
    // MARK: - Acciones
    
    @objc func doneButtonTapped() { //funcion para saber la opcion que presionò el usuario
        
        // Cerrar el menú desplegable y actualizar el campo de texto o botón con la opción seleccionada
        txtEstado.text = selectedOptionId
        txtEstado.resignFirstResponder() // Cerrar el teclado
    }
    
    // MARK: - DataSource y DataDelegate de la table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemsCategorias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tablaCategoria.dequeueReusableCell(withIdentifier: "celdaCategoria", for: indexPath) as! CeldaCategoriaTableViewCell
        
        celda.lblNombreCate.text = itemsCategorias[indexPath.row].nombCate
        celda.lblEstadoCate.text = itemsCategorias[indexPath.row].estado
        
        
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //imprimo id_producto
        if let id_cate = itemsCategorias[indexPath.row].id_categoria {
            txtCodigo.text = String(id_cate)
        } else {
            txtCodigo.text = nil
        }
        if let nombre = itemsCategorias[indexPath.row].nombCate {
            txtNombreCategoria.text = String(nombre)
        } else {
            txtNombreCategoria.text = nil
        }
        if let descrip = itemsCategorias[indexPath.row].descripcionCate {
            txtDescripcion.text = String(descrip)
        } else {
            txtDescripcion.text = nil
        }
        if let estado = itemsCategorias[indexPath.row].estado {
            txtEstado.text = String(estado)
            /*if estado == "A" {
                txtEstado.text = "ACTIVO"
            } else if estado == "I" {
                txtEstado.text = "INACTIVO"
            }*/
        } else {
            txtEstado.text = nil
        }
        
    }
    
    
    
    
    func agregarCategoria() {
        let urlString = linkAPI.baseUrlString + "categoria/agregarCategoria"
        
        guard let nombreCate = txtNombreCategoria.text,
            let descripcionCategoria = txtDescripcion.text,
            let estadoCate = txtEstado.text else {
                return
        }
        
        let nuevoCategoria = Categoria(id_categoria: nil,
                                       nombCate: nombreCate,
                                       descripcionCate: descripcionCategoria,
                                       estado: estadoCate)
        
        guard let jsonData = try? JSONEncoder().encode(nuevoCategoria) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                let decodificador = JSONDecoder()
                
                if let categoriaAgregado = try? decodificador.decode(Categoria.self, from: data) {
                    // Producto agregado con éxito
                    self.itemsCategorias.append(categoriaAgregado)
                    print("categoria agregada")
                    DispatchQueue.main.async {
                        self.tablaCategoria.reloadData()
                    }
                } else {
                    // Error al decodificar la respuesta
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume()
    }
    
    
    
    func actualizarCategoria() {
        let urlString = linkAPI.baseUrlString + "categoria/actualizarCategoria"
        
        guard let codigo = Int(txtCodigo.text ?? ""),
            let nombreCate = txtNombreCategoria.text,
            let descripcionCategoria = txtDescripcion.text,
            let estadoCate = txtEstado.text else {
                return
        }
        
        let categoriaActualizado = Categoria(id_categoria: codigo,
                                            nombCate: nombreCate,
                                            descripcionCate: descripcionCategoria,
                                            estado: estadoCate)
        
        guard let jsonData = try? JSONEncoder().encode(categoriaActualizado) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                let decodificador = JSONDecoder()
                
                if let respuesta = try? decodificador.decode(APIResponse.self, from: data) {
                    print("Message: \(respuesta.message) categoria actualizada")
                } else {
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume()
    }
    
    
    
    func eliminarCategoria() {
        let urlString = linkAPI.baseUrlString + "categoria/eliminarCategoria"
        
        guard let codigo = Int(txtCodigo.text ?? "") else {
            return
        }
        
        let productoAEliminar = Categoria(id_categoria: codigo,
                                          nombCate: nil,
                                          descripcionCate: nil,
                                          estado: nil)
        
        guard let jsonData = try? JSONEncoder().encode(productoAEliminar) else {
            return
        }
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "DELETE"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Agregar el valor de la cookie al encabezado de la solicitud
        if let cookieValue = obtenerCookieValue() {
            request.setValue(cookieValue, forHTTPHeaderField: "Authorization")
        }
        
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            if let data = data {
                let decodificador = JSONDecoder()
                
                if let respuesta = try? decodificador.decode(APIResponse.self, from: data) {
                    print("Message: \(respuesta.message) ")//si no se elimino, muestra mensaje
                    
                    if respuesta.success == true{ //en caso de que si se haya eliminado
                        print("categoria eliminada ✔" )
                    }
                    
                } else {
                    print("Error al decodificar la respuesta del servidor")
                }
            }
            }.resume()
    }
    
    func obtenerCookieValue() -> String? {
        // Obtener la cookie creada previamente en otro controlador
        // y devolverla para su uso en la solicitud HTTP actual
        // Puedes ajustar este código según cómo hayas almacenado y accedido a la cookie
        let cookieName = "respuestaAPI"
        if let cookie = HTTPCookieStorage.shared.cookies?.first(where: { $0.name == cookieName }) {
            //print("RespuestaCookie:Bearer \( cookie.value)   ***FIN")
            return "Bearer " + cookie.value
            
        }
        return nil
    }
    
    
    
    
    
    
    @IBAction func btnRegresar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil) //cerrar la instancia actual.
        
    }
    
    
    @IBAction func btnAgregar(_ sender: UIButton) {
        agregarCategoria()
    }
    @IBAction func btnActualizar(_ sender: UIButton) {
        actualizarCategoria()
        
    }
    @IBAction func btnEliminar(_ sender: UIButton) {
        eliminarCategoria()
    }
    @IBAction func btnActualizarListaCategoria(_ sender: UIButton) {
        obtenerCategorias()
        self.tablaCategoria.reloadData()
        
    }
    
    

}











































