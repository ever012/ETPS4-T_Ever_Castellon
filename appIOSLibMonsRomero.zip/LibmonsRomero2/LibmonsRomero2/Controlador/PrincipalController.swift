//
//  PrincipalController.swift
//  LibmonsRomero2
//
//  Created by Development on 28/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class PrincipalController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    var arrdata = ["Productos","eMAIL","pASSWORD","mOBILE","LOGOUT"]
    var arrimg = [#imageLiteral(resourceName: "person_icon"),#imageLiteral(resourceName: "email_icon"),#imageLiteral(resourceName: "editar"),#imageLiteral(resourceName: "editProfile"),#imageLiteral(resourceName: "salir(1)")]
    
    @IBOutlet weak var viewoculto: UIView!
    @IBOutlet weak var menuLateral: UITableView!
    
    var isViewOcultoAbierto: Bool = false
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TitulosTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TitulosTableViewCell
        cell.img.image = arrimg[indexPath.row]
        cell.lbl.text = arrdata[indexPath.row]
        return cell
    }
    
    //saber que fila de la tabla presionò el usuario
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{ //productos
            let producto:ProductoController =
                self.storyboard?.instantiateViewController(withIdentifier: "vistaProducto") as! ProductoController
            
            self.navigationController?.pushViewController(producto, animated: true)
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        viewoculto.isHidden = true //al iniciar la app iniciarà oculto el menu
        menuLateral.backgroundColor = UIColor.groupTableViewBackground
        isViewOcultoAbierto = false
    }

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnMenu(_ sender: UIBarButtonItem) {
        menuLateral.isHidden = false //muestro el menu
        viewoculto.isHidden = false //muestro la vista
        self.view.bringSubview(toFront: viewoculto)
        if !isViewOcultoAbierto{
            isViewOcultoAbierto = true
            //la animacion iniciarà de esta forma
            viewoculto.frame = CGRect(x: 0, y: 64, width: 0, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 0, height: 427)
            UIView.setAnimationDuration(0.3)
            UIView.setAnimationDelegate(self)
            UIView.beginAnimations("TableAnimation", context: nil)
            //la animacion terminarà de esta forma
            viewoculto.frame = CGRect(x: 0, y: 64, width: 240, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 240, height: 427)
            UIView.commitAnimations()
        }else{
            menuLateral.isHidden = true
            viewoculto.isHidden = true
            isViewOcultoAbierto = false
            //la animacion iniciarà de esta forma
            viewoculto.frame = CGRect(x: 0, y: 64, width: 240, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 240, height: 427)
            UIView.setAnimationDuration(0.3)
            UIView.setAnimationDelegate(self)
            UIView.beginAnimations("TableAnimation", context: nil)
            //la animacion terminarà de esta forma
            viewoculto.frame = CGRect(x: 0, y: 64, width: 0, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 0, height: 427)
            UIView.commitAnimations()
        }
        
    }
    

}
