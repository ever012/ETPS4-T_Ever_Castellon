//
//  TitulosTableViewCell.swift
//  LibmonsRomero2
//
//  Created by Development on 27/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class TitulosTableViewCell: UITableViewCell {

    //

    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
    
   

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
