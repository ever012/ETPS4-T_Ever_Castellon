//
//  TituloTableViewCell.swift
//  LibmonsRomero2
//
//  Created by Development on 27/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class TituloTableViewCell: UITableViewCell {

    
    @IBOutlet weak var imgIcon: UIImageView!
    
    @IBOutlet weak var lblTitulo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
