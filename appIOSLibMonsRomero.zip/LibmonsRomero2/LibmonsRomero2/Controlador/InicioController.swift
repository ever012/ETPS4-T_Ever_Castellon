//
//  ViewController.swift
//  LibmonsRomero2
//
//  Created by Development on 27/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class InicioController: UIViewController, UITableViewDelegate, UITableViewDataSource{
   
    
    // Arreglos para los datos de la tabla
    var arrdata = ["Productos","Categorias","Movimientos","Ganancias","Cerrar Sesion"]
    var arrimg = [#imageLiteral(resourceName: "producto"),#imageLiteral(resourceName: "empleados"),#imageLiteral(resourceName: "compras"),#imageLiteral(resourceName: "reportes"),#imageLiteral(resourceName: "salir(1)")]
    
    @IBOutlet weak var viewoculto: UIView!
    @IBOutlet weak var menuLateral: UITableView!
    
    var isViewOcultoAbierto: Bool = false //saber si la vista del menu se ve o no
    
    // Función del protocolo UITableViewDataSource para obtener el número de filas en la tabla
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    // Función del protocolo UITableViewDataSource para obtener la celda de cada fila
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //asigno el table view cell que cree "TitulosTableViewCell" a la celda en la tabla, a modo de sustituir el que tiene por defecto, por el de "TitulosTableViewCell"
        let cell:TitulosTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TitulosTableViewCell
        //establezco los valores de la celda
        cell.img.image = arrimg[indexPath.row]
        cell.lbl.text = arrdata[indexPath.row]
        return cell
    }
    
    //funcion para saber que fila de la tabla presionò el usuario
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Verificar qué fila fue seleccionada
        //Muestro las vistas
        if indexPath.row == 0{ //productos
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaProducto")
            self.present(vistaMostrada, animated: true, completion: nil)
        }
        if indexPath.row == 1{ //categoria
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaCategoria")
            self.present(vistaMostrada, animated: true, completion: nil)
        }
        if indexPath.row == 2{ //movimiento
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaMovimiento")
            self.present(vistaMostrada, animated: true, completion: nil)
        }
        if indexPath.row == 3{ //ganancias
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaGanancias")
            self.present(vistaMostrada, animated: true, completion: nil)
        }
        if indexPath.row == 4{ //cerrar sesion
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let vistaMostrada = storyboard.instantiateViewController(withIdentifier: "vistaLogin") as? LoginController {
                vistaMostrada.modalPresentationStyle = .fullScreen //la vista se mostrarà a pantalla completa
                self.present(vistaMostrada, animated: true, completion: nil)
            }
            
        }
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configurar la vista inicial
        viewoculto.isHidden = true //al iniciar la app iniciarà oculto el menu
        menuLateral.backgroundColor = UIColor.groupTableViewBackground //color de fondo por defecto, al idea es que coincida con el color predeterminado de fondo utilizado en las tablas y listas en iOS
        
        isViewOcultoAbierto = false //al inicio el menu estarà oculto
    }
    
    
    // Acción del botón de menú sin Navigation Controller
    @IBAction func btnMenuSinNavControl(_ sender: UIButton) {
        
        menuLateral.isHidden = false //muestro el menu
        viewoculto.isHidden = false //muestro la vista donde esta el menu
        self.view.bringSubview(toFront: viewoculto)//coloco la vista al frente de cualquier elemento
        if !isViewOcultoAbierto{ //si la varible es falsa (false)
            isViewOcultoAbierto = true //pongo la variable como verdadera
            //iniciarà la animacion desde 0 pixeles
            viewoculto.frame = CGRect(x: 0, y: 64, width: 0, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 0, height: 427)
            UIView.setAnimationDuration(0.3) //lo que va a durar la animacion en segundos
            UIView.setAnimationDelegate(self) //el objeto actual(self) harà la animacion
            UIView.beginAnimations("TableAnimation", context: nil) //inicio una animacion
            //empzarà en una esquina y se expandirà hasta un tamaño especifico de 427px
            viewoculto.frame = CGRect(x: 0, y: 64, width: 240, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 240, height: 427)
            UIView.commitAnimations()
        }else{ //si la varible es verdadera (true)
            menuLateral.isHidden = true //oculto el menu
            viewoculto.isHidden = true //oculto la vista donde esta el menu
            isViewOcultoAbierto = false //pongo la varible como falsa para el if
            //iniciarà la animacion con este tamaño
            viewoculto.frame = CGRect(x: 0, y: 64, width: 240, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 240, height: 427)
            UIView.setAnimationDuration(0.3) //lo que va a durar en segundos
            UIView.setAnimationDelegate(self)//el objeto actual(self) harà la animacion
            UIView.beginAnimations("TableAnimation", context: nil) //inicio una animacion
            //aquì hace lo contrarìo es decir, se cerrarà hasta llegar a cero pixeles
            viewoculto.frame = CGRect(x: 0, y: 64, width: 0, height: 427)
            menuLateral.frame = CGRect(x: 0, y: 0, width: 0, height: 427)
            UIView.commitAnimations()
        }
    }
    
    
}










































