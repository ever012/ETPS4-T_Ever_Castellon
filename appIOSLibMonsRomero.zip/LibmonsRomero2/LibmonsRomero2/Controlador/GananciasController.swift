//
//  GananciasController.swift
//  LibmonsRomero2
//
//  Created by Development on 30/5/23.
//  Copyright © 2023 Development. All rights reserved.
//

import UIKit

class GananciasController: UIViewController {

    //estructura para las ganancias generales
    struct GananciasGeneralesModelo: Codable {
        var result: [GananciasGenerales] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct GananciasGenerales: Codable{
        //las variables se deben llamar igual a como esta en la API
        let ventasGenerales: Decimal?
        let comprasGenerales: Decimal?
        let gananciaGeneral: Decimal?
    }
    
    //estructura para las ganancias diarias
    struct GananciasDiariasModelo: Codable {
        var result: [GananciasDiarias] //la variable se debe llamar igual a la variable que tiene el json [{ }]
    }
    struct GananciasDiarias: Codable{
        //las variables se deben llamar igual a como esta en la API
        let ventasDiarias: Decimal?
        let comprasDiarias: Decimal?
        let gananciaDiarias: Decimal?
    }
    
    //estructura de la respuesta de la API
    struct APIResponse: Codable {
        let success: Bool
        let message: String
        let result: String
    }
    
    
    //arreglos donde se guardarà la informacion obtenida de la api
    var itemsGananciasGenerales : [GananciasGenerales] = []
    var itemsGananciasDiarias : [GananciasDiarias] = []
    
    
    //OBJETOS DE LA VISTA PRODUCTOS
    @IBOutlet weak var lblVentasGenerales: UILabel!
    @IBOutlet weak var lblComprasGenerales: UILabel!
    @IBOutlet weak var lblGananciaGeneral: UILabel!
    
    
    @IBOutlet weak var lblTituloVentas: UILabel!
    @IBOutlet weak var lblTituloCompras: UILabel!
    @IBOutlet weak var lblTituloGanancias: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        obtenerGananciasGenerales()
        obtenerGananciasDiarias()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func obtenerGananciasGenerales(){
        let urlString = linkAPI.baseUrlString + "otros/ganancias"
        
        if let url = URL(string: urlString){
            if let data = try? Data(contentsOf: url){
                
                let decodificador = JSONDecoder()
                if let datosDecodificados = try? decodificador.decode(GananciasGeneralesModelo.self, from: data) {
                    
                    //print("datosDecodificados: \(datosDecodificados.result)")// prueba
                    itemsGananciasGenerales = datosDecodificados.result
                    
                }
            }
        }
    }
    
    
    func obtenerGananciasDiarias(){
        let urlString = linkAPI.baseUrlString + "otros/gananciasDiarias"
        
        if let url = URL(string: urlString){
            if let data = try? Data(contentsOf: url){
                
                let decodificador = JSONDecoder()
                if let datosDecodificados = try? decodificador.decode(GananciasDiariasModelo.self, from: data) {
                    
                    //print("datosDecodificados: \(datosDecodificados.result)")// prueba
                    itemsGananciasDiarias = datosDecodificados.result
                    
                }
            }
        }
    }
    
    
    @IBAction func btnGananciasGenerales(_ sender: UIButton) {
        if let ventasGenerales = itemsGananciasGenerales.first?.ventasGenerales {
            lblTituloVentas.text = "Ventas Generales"
            lblVentasGenerales.text = String(describing: ventasGenerales)
        } else {
            lblTituloVentas.text = "Ventas Generales"
            lblVentasGenerales.text = "0.00"
        }
        if let compras = itemsGananciasGenerales.first?.comprasGenerales {
            lblTituloCompras.text = "Compras Generales"
            lblComprasGenerales.text = String(describing: compras)
        } else {
            lblTituloCompras.text = "Ventas Generales"
            lblComprasGenerales.text = "0.00"
        }
        if let ganancias = itemsGananciasGenerales.first?.gananciaGeneral {
            lblTituloGanancias.text = "Ganancias Generales"
            lblGananciaGeneral.text = String(describing: ganancias)
        } else {
            lblTituloGanancias.text = "Ganancias Generales"
            lblGananciaGeneral.text = "0.00"
        }
    }
    
    @IBAction func btnGananciasDiarias(_ sender: UIButton) {
        if let ventasGenerales = itemsGananciasDiarias.first?.ventasDiarias {
            lblTituloVentas.text = "Ventas Diarias"
            lblVentasGenerales.text = String(describing: ventasGenerales)
        } else {
            lblTituloVentas.text = "Ventas Diarias"
            lblVentasGenerales.text = "0.00"
        }
        if let compras = itemsGananciasDiarias.first?.comprasDiarias {
            lblTituloCompras.text = "Compras Diarias"
            lblComprasGenerales.text = String(describing: compras)
        } else {
            lblTituloCompras.text = "Ventas Diarias"
            lblComprasGenerales.text = "0.00"
        }
        if let ganancias = itemsGananciasDiarias.first?.gananciaDiarias {
            lblTituloGanancias.text = "Ganancias Diarias"
            lblGananciaGeneral.text = String(describing: ganancias)
        } else {
            lblTituloGanancias.text = "Ventas Diarias"
            lblGananciaGeneral.text = "0.00"
        }
        
    }
    
    
    @IBAction func btnCerrar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil) //cerrar la instancia actual.
        
    }
    
}





















